module github.com/mahadzar81/opentofu-provider-ansible-adagios/test

go 1.22

require (
	github.com/aws/aws-sdk-go v1.55.5
	github.com/gruntwork-io/terratest v0.47.1
	github.com/hashicorp/terraform-json v0.22.1
	github.com/stretchr/testify v1.9.0
	golang.org/x/crypto v0.24.0
)
